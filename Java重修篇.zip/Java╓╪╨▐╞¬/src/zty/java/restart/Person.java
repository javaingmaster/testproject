package zty.java.restart;

public class Person{
	String name;
	int position;
	public Person(){}
	public Person(String name){
		this.name=name;
	}
}
