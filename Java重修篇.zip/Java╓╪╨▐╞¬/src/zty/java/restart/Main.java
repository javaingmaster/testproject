package zty.java.restart;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class Main {	
	
	public static void main(String[] aaa){
		
		int[] arr={12,7,88,9,0,12,4,2,78,45,5,-1,65,77,32,61};
		NumberTheroy nt=new NumberTheroy();
		//nt.getPrimeNumber(arr);
		System.out.print(nt.getGreatestCommonDivisor(231, 6));
		
		/*JavaUnionFind jud=new JavaUnionFind(4);
		for(int i=0;i<jud.pre.length;i++){
			jud.find(i);
		}
		jud.join(0, 3);
		jud.showPre();*/
		
		/*for(Object a : staff){
			System.out.println(a);
		}*/
		
		/*StringBuilder sb=new StringBuilder("hello world");
		sb.append("the price of this shit is ");
		sb.append(new Integer(100));
		sb.insert(0, "insert a word ");
		//System.out.println(sb.lastIndexOf("s", 5));
		//sb.deleteCharAt(1);
		//sb.delete(0, 10);
		//sb.replace(0, sb.length(), "replace it!");
		//sb.reverse();
		
		System.out.println(sb.toString());
        		
		
		//myPattern p=new myPattern();
		//p.test();
		//System.out.println(Arrays.toString(p.split("\\d", "sdaf1sg5sd")));
		//List<String> l=p.getUrl("www.qq.com++http://www.qq.com");
		//Iterator iter=l.iterator();
		//while(iter.hasNext()){
		//	System.out.println(iter.next());
		//}
		
		//JavaIO jio=new JavaIO();
		//jio.readAsCharacter("D:\\3\\test.txt");
		//jio.readAsCharacterByBuffer("D:\\3\\test.txt");
		//jio.writeDataToFile("D:\\3\\testwrite.txt");
		//File f=new File("D:\\3\\tesdt.txt");
		//System.out.println(f.exists());
		//jio.readByRandomAccessFile("D:\\3\\testwrite.txt", 50);
		//jio.readUrlByBufferToFile("http://www.qq.com", "D:\\3\\urltxt.txt");
		//jio.readAsBinary("D:\\3\\testwrite.txt");
		//jio.readAsBinaryToFile("D:\\3\\testwrite.txt", "D:\\3\\readasbinarytofile.txt", 15);
		
		
		/*ConcurrentLinkedQueue<Integer> q=new ConcurrentLinkedQueue<Integer>();//�������̷߳��ʵ��ޱ߽����
		q.add(6);
		q.add(10);
		Iterator<Integer> iter=q.iterator();
		while(iter.hasNext()){
			System.out.println(iter.next());
		}
		/*Bank bank=new Bank(5);
		Acount a0=new Acount(bank,0);
		Acount a1=new Acount(bank,1);
		Acount a2=new Acount(bank,2);
		Acount a3=new Acount(bank,3);
		Acount a4=new Acount(bank,4);
		
		Thread tbank=new Thread(bank);
		tbank.setName("bank");
		Thread t0=new Thread(a0);
		tbank.setName("a0");
		Thread t1=new Thread(a1);
		tbank.setName("a1");
		Thread t2=new Thread(a2);
		tbank.setName("a2");
		Thread t3=new Thread(a3);
		tbank.setName("a3");
		Thread t4=new Thread(a4);
		tbank.setName("a4");
		
		tbank.start();
		t0.start();
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		
		try {
			Thread.currentThread().sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		int sum=0;
		System.out.println("ȫ������֮��");
		for(int i=0;i<5;i++){
			System.out.print(bank.acounts[i]+"  ");
			sum+=bank.acounts[i];
		}
		System.out.println();
		System.out.println("�ܶ�: "+sum);
		    //Thread.currentThread().setPriority(5);
		   // Thread.currentThread().setName("main");
			//Runnable r=new MyThread();
			//Thread t=new Thread(r);
			//t.setPriority(10);
			//t.setName("t");
			//t.start();
				//t.sleep(1000);ע���߳���ִ��sleep��wait����interrupt��û���ã���Ϊ��ʱ�߳�������״̬
				//t.interrupt();
				/*if(t.isInterrupted()){
					System.out.println("�߳�"+t.getName()+"�Ѿ����ж�");
				}else{
					System.out.println(t.getName()+"�̼߳���ִ��");
				}*/
			
			//t.currentThread().isInterrupted()�߳��Ƿ��ж�
			//t.interrupt();�ж��߳�
			/*while(true){
			System.out.println(Thread.currentThread().getName());
			}*/
			//һ���߳�ֻ�б�ִ��yield���߱�������ȴ�ʱ���̲߳�ʧȥ����Ȩ
			//��a�߳�����b�̵߳���ʱ����������ֱ���������
			//�߳�run���������˳����߳����������߳̽�����ֹ״̬
		   //yieldʹ�߳��ò�����cpu�ø����ȼ����ڵ��ڸ��̵߳��߳�
			
			//t.setDefaultUncaughtExceptionHandler(Thread.getDefaultUncaughtExceptionHandler());
			
	}
	
}

