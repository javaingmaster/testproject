package zty.java.commandcopy;

public interface Command {
	public void execute();
}
