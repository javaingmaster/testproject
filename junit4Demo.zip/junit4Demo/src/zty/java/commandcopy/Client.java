package zty.java.commandcopy;

public class Client {
	public static void main(String[] a){
		Receiver r=new Receiver(); 
		
		Command c=new CommandImp(r);
		
		Invoker iv=new Invoker(c);
		
		iv.invoke();
	}
}
