package zty.java.commandcopy;

public class Receiver {
	public void operation(){
		System.out.println("action");
	}
}
