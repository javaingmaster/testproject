package zty.java.component;

public interface Component {
	public void dosomething();
}
