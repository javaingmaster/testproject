package zty.java.component;

public class Leaf implements Component{

	@Override
	public void dosomething() {
		// TODO Auto-generated method stub
		System.out.println("ִ��");
	}
	
}
