package zty.java.componentcopy;

public class Leaf implements Component{

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		System.out.println("do");
	}

}
