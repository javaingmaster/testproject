package zty.java.componentcopy;

import java.util.ArrayList;
import java.util.List;

public class Composite implements Component{

	private List<Component> composite;
	
	public Composite(){
		this.composite=new ArrayList<Component>();
	}
	
	public void add(Component c){
		this.composite.add(c);
	}
	
	public void remove(Component c){
		this.composite.remove(c);
	}
	
	public List<Component> getAll(){
		return this.composite;
	}
	
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		for(Component c: composite){
			c.execute();
		}
	}
	
}
