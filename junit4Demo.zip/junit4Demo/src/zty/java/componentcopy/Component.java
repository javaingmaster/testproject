package zty.java.componentcopy;

public interface Component {
	public void execute();
}
