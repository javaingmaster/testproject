package zty.java.command;

public class Receiver {
	public void doAction(){
		System.out.println("doAction in Receiver");
	}
}
