package zty.java.command;

public interface Command {
	public void execute();
}
