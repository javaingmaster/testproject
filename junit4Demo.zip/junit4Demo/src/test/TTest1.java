package test;

import org.junit.Test;

public class TTest1 {
	@Test
	public void ttest1(){
		System.out.println("ttest1");
	}

}
