package test;

import org.junit.Test;

public class TTest2 {
	@Test
	public void ttest2(){
		System.out.println("ttest2");
	}
}
