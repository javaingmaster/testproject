package test;

import org.junit.Test;

public class TTest3 {
	@Test
	public void ttest3(){
		System.out.println("ttest3");
	}
}
