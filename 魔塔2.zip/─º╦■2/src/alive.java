
public class alive//�ж��Ƿ񻹻���
{
	boolean dec(player p)
	{
		if(p.alive==false)
		{
			
		}
		return false;
	}
}
